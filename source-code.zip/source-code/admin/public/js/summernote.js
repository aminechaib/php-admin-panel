
$('#summernote').summernote({
  placeholder: 'Hello Bootstrap 5',
  tabsize: 2,
  height: 100
});
