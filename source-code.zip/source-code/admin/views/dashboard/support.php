

        <div class="row support">
            <div class="col-sm-6">

                <div class="info-box">
                    <div class="row">
                    <div class="col-sm-4 info-icon">
                        <i class="fa fa-file-text-o"></i>
                    </div>
                    <div class="col-sm-8">
                        <a href="">Blog</a>
                        <p>You can read blog to create admin panel step by step </p>
                    </div>
                    </div>
                </div>

            </div>
            <div class="col-sm-6">

                <div class="info-box">
                <div class="row">
                    <div class="col-sm-4 info-icon">
                    <i class="fa fa-cogs"></i>
                    </div>
                    <div class="col-sm-8">
                        <a href=""> Customisation </a>
                        <p>Feel free to contact us for your project's specific requirements</p>
                    </div>
                </div>
                </div>

            </div>
        </div>

        <div class="row support">
            <div class="col-sm-6">

                <div class="info-box">
                    <div class="row">
                    <div class="col-sm-4 info-icon">
                    <i class="fa fa-github"></i>
                    </div>
                    <div class="col-sm-8">
                        <a href="">Github</a>
                        <p>You can follow us on github for getting future updates </p>
                    </div>
                    </div>
                </div>

            </div>
            <div class="col-sm-6">

                <div class="info-box">
                <div class="row">
                    <div class="col-sm-4 info-icon">
                    <i class="fa fa-folder"></i>
                    </div>
                    <div class="col-sm-8">
                        <a href=""> Projects </a>
                        <p>You can get more projects for your specific requirements</p>
                    </div>
                </div>
                </div>

            </div>
        </div>


       </div>