<div class="intro">
<h1 class="text-center mt-4">Welcom John</h1>
        <p>Hello John, This is a basic admin panel created in PHP,
            intended to provide a foundational configuration 
            for web development. The purpose of this admin panel
            is to serve as a starting point for setting up the 
            administrative aspect of your project. Once you understand it,
            you can enhance and expand its features and functionality
                to align with your project's specific requirements.
        </p>

</div>