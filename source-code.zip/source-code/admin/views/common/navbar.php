<nav class="navbar navbar-expand-sm bg-light navbar-light mb-3">
  <div class="container-fluid">
  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
      <span class="navbar-toggler-icon"></span>
    </button>
    <a class="navbar-brand" href="#">Website Name</a>

      <!-- right nav--->
      <ul class="navbar-nav justify-content-end">
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">John</a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="dashboard.php?page=profile">Profile</a></li>
            <li><a class="dropdown-item" href="scripts/AdminLogout.php">Logout</a></li>
          </ul>
        </li>
      </ul>
    <!-- right nav--->

  </div>
</nav>